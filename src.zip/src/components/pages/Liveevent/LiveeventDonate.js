import React from 'react'
import './LiveeventDonate.css'

export default function LiveeventDonate() {
    return (
        <div className="led-container">
            <h1 className='led-header'>
                THE TIP JAR
            </h1>

            <div className='led-layer' />
        </div>
    )
}
