import React from 'react'
import './Dashboard.css'

const Dashboard = props => {
    return (
        <h1>Logged In!</h1>
    )
}

export default Dashboard