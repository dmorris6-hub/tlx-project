import React from 'react'
import EmailPassword from '../../../EmailPassword/EmailPassword'

const Recover = props => {
    return (
        <EmailPassword />
    )
}

export default Recover
