import React from 'react'
import '../../../App.css'
import Footer from '../../Footer'
import PastworkHero from './PastworkHero'

function Pastwork() {
    return (
        <>
            <PastworkHero />
            <Footer />
        </>
    )
}

export default Pastwork
