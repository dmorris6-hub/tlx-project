export const firebaseConfig = {
    apiKey: "AIzaSyDU3HdOEbl9Vi3dHUXjrFBI9_JpAnFP278",
    authDomain: "tlxbase.firebaseapp.com",
    databaseURL: "https://tlxbase.firebaseio.com",
    projectId: "tlxbase",
    storageBucket: "tlxbase.appspot.com",
    messagingSenderId: "1095622256209",
    appId: "1:1095622256209:web:5a15f4b28402fa1bba7a70"
};